$(document).ready(function(){
    $('.menu').click(function(){
   $('.computer,.laptop,.tab,.mobile,.smobile,.cross').toggle();
});
$('.cross').click(function(){
$('.computer,.laptop,.tab,.mobile,.smobile,.cross').hide();
});
});